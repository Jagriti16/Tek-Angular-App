import { Component } from "@angular/core";
import { AshuService } from '../ashu.service';
import { Router } from '@angular/router';

@Component({
   selector :"app-navbar",
   templateUrl:"./navbar.component.html",
   providers:[AshuService]
})
export class NavbarComponent{
   projecttitle:any = "Ashu's Cake Gallery"
   searchtext:any
   color:any
   isloggedin:any
   constructor(private ashutrainer : AshuService , private router : Router){
         this.isloggedin = localStorage["token"]?true:false
   }

   ngDoCheck(){
      if(localStorage["token"]){
         this.isloggedin = true
      }
      else{
         this.isloggedin =  false
      }
   }

   search(){
      if(this.searchtext)
      this.router.navigate(["/search"], {queryParams:{q:this.searchtext}})
   }
}